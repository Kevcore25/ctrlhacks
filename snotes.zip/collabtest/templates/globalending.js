if (getCookie('darkmode') == 'true') {
    firstTime = true;
    changeMode();
    document.getElementById('changemode').innerHTML = "Light Mode"
}