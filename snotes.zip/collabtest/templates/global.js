

// Reference: https://www.w3schools.com/js/js_cookies.asp
function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/;SameSite=Lax";
}


var darkmode = false;
var firstTime = false;



function changeMode() {
    darkmode = !darkmode;
    
    let DMElements = ['body'];
    
    for (var element in DMElements) {
        if (darkmode == true) {document.getElementById(DMElements[element]).classList.add('darkmode'); document.getElementById('changemode').innerHTML = "Light Mode";}
        else {document.getElementById(DMElements[element]).classList.remove('darkmode');document.getElementById('changemode').innerHTML = "Dark Mode";}
        if (firstTime == false) {document.getElementById(DMElements[element]).classList.add('bgtrans')}
        firstTime = false;
    }

    setCookie('darkmode', darkmode,  1);
}


function toolbar() {

    var http = new XMLHttpRequest();
    http.open("GET", "toolbar.html", true);
    http.onreadystatechange = function() {
    if (http.readyState == 4 && http.status == 200) {
        document.getElementById('toolbar').innerHTML = (http.responseText);
      }
    }
    http.send();

}
// Run these at start
toolbar(); 

document.body.style.zoom=0.5;this.blur();